
***********************************************************************************************************
***********************************************************************************************************
This is the implemention of WMCNN, and it is based on the Matlab demo code for 
"Learning a Deep Convolutional Network for Image Super-Resolution" (ECCV 2014).

This code is for academic purpose only. Not for commercial/industrial activities.

NOTE:
The result can be slightly different from the paper due to transferring across platforms.

If you have any questions, please contact wtw_upc@163.com
***********************************************************************************************************
***********************************************************************************************************


Usage:

demo_SR.m - demonstrate super-resolution using SRCNN.m

function:

SRCNN.m - realize super resolution given the model parameters