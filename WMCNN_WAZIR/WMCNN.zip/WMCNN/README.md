An implementation of wavelet multiscale convolutional neural networks for manuscript "Aerial Image Super Resolution via Wavelet Multiscale Convolutional Neural Networks".
For testing, just open the demo_SR_image.m in the WMCNN_test folder and run.
For training, you need to train four separate CNNs and remember to modify the corresponding path and parameters. For difference of platforms and versions of software and librariry, the results may be slightly different. 
