# Useful Scripts

- `Prepare_TrainData_HR_LR.m`: Prepare training data pairs
- `plot_log`: Plot the training log (saved in `./experiments/xxx/records/train_records.csv`)

