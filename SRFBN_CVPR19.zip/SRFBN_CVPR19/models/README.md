Place unzipped models here.
