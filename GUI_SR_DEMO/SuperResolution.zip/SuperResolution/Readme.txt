REQUIRES MATLAB 2014 and above
Read Me:
1. Data folder contains different samples of images to test our work.
2. Keren.m contains keren image registration algorithm.
3. Interpolation.m contains image reconstruction algorithm using bicubic interpolation.
4. Scale.m contains FMT image registrationn algorithm.
5. Blurmetric.m contains blur calculation algorithm which gives blurness of a image.
6. Untitled.m contains gui of the project.
7. Remaining are helper codes used in the algorithm.

Steps to execute :
1. Run untitled.m
2. Now our gui appears in which we have to load images using load button and give scale value .
3. After this registration button has to be pressed which performs  image registration.
4. A dialog appears which shows progress of image registration.
5. After the completion of image registration then perform image reconstruction by pressing reconstruction button.
6. Outputs are displayed in figures with titles.


