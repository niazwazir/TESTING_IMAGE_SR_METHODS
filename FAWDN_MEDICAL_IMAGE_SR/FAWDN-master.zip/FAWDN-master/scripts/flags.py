# -*- coding: utf-8 -*-
# @Time    : 2019-05-21 17:13
# @Author  : LeeHW
# @File    : flags.py
# @Software: PyCharm
train_HR_dir='./data/DIV2K_train_HR'
save_dir='./data/Prepare'