% Initialize path
M_ROOT = fileparts(which(mfilename));
addpath([M_ROOT '/vgg']);
addpath([M_ROOT '/ojw']);
clear M_ROOT